// Run from a checkout with @playwright/test installed: node <path>/verify.cjs
const { createRequire } = require('node:module');
const path = require('node:path');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const { chromium } = createRequire(path.join(process.cwd(), 'package.json'))('@playwright/test');
const output = path.join(__dirname, 'screenshots');
fs.mkdirSync(output, { recursive: true });
function luminance(hex) {
  const channels = hex.slice(1).match(/../g).map(v => parseInt(v, 16) / 255).map(v => v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4);
  return channels[0] * .2126 + channels[1] * .7152 + channels[2] * .0722;
}
function contrast(a, b) { const x=luminance(a), y=luminance(b); return (Math.max(x,y)+.05)/(Math.min(x,y)+.05); }
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1100 } });
  const errors=[];
  async function capture(filename) {
    await page.screenshot({path:path.join(output,filename),fullPage:true,animations:'disabled',style:'#toast,.toolbox{visibility:hidden!important}'});
  }
  page.on('pageerror', e => errors.push(e.message));
  page.on('response', r => { if (r.status() >= 400) errors.push(`${r.status()} ${r.url()}`); });
  await page.goto('http://127.0.0.1:4174/001-visual-identity/');
  await page.waitForFunction(() => document.getElementById('font-state')?.textContent === 'All 8 specimen fonts loaded locally');
  const fontNames = await page.evaluate(() => fontChecks);
  assert.equal(fontNames.length,8);
  const contrastResults=[];
  for (const id of ['A','B','C','D']) {
    await page.locator(`[data-palette="${id}"]`).click();
    await page.evaluate(() => Promise.all(document.getAnimations().map(a => a.finished)));
    const p = await page.evaluate(id => palettes.find(p => p.id === id), id);
    const pairs={bodyOnCanvas:contrast(p.colors[2],p.colors[0]),bodyOnPanel:contrast(p.colors[2],p.colors[1]),mutedOnPanel:contrast(p.colors[3],p.colors[1]),accentOnPanel:contrast(p.colors[5],p.colors[1]),buttonText:contrast(p.colors[6],p.colors[5])};
    for (const [role,ratio] of Object.entries(pairs)) assert.ok(ratio>=4.5, `${id} ${role}: ${ratio}`);
    contrastResults.push({palette:id,...Object.fromEntries(Object.entries(pairs).map(([k,v])=>[k,Number(v.toFixed(2))]))});
    await capture(`palette-${id.toLowerCase()}.png`);
  }
  await page.locator('[data-palette="A"]').click();
  await page.locator('#search').fill('Tidemark');
  assert.equal(await page.locator('.series-card').count(),1);
  await page.locator('#search').fill('');
  await page.locator('#status-filter').selectOption('Paused');
  assert.equal(await page.locator('.series-card').count(),1);
  await page.locator('#status-filter').selectOption('all');
  await page.locator('#preview-empty').click();
  assert.equal(await page.locator('.series-card').count(),0);
  await page.locator('#preview-empty').click();
  await page.locator('#add-series').click();
  await page.locator('#sample-name').fill('The Lantern Archive');
  await page.locator('#add-form button[type=submit]').click();
  assert.equal(await page.locator('.series-card').count(),4);
  await page.reload();
  await page.evaluate(() => document.fonts.ready);
  await page.locator('#pick-palette').click();
  await page.locator('[data-section="logos"]').click();
  await page.locator('[data-pick-logo="L1"]').click();
  await capture('logos-light.png');
  await page.locator('#logo-inverse').click();
  await capture('logos-dark.png');
  const logos=await page.evaluate(()=>marks.map(m=>({id:m.id,art:m.art.replace('var(--mark-cut,#e3e0d7)','#ffffff')})));
  const logoDir=path.join(__dirname,'assets','logos');fs.mkdirSync(logoDir,{recursive:true});
  for(const m of logos)fs.writeFileSync(path.join(logoDir,m.id.toLowerCase()+'.svg'),m.art);
  await page.locator('[data-section="typography"]').click();
  await page.locator('[data-pick-type="T1"]').click();
  await capture('typography-light.png');
  await page.locator('#type-night').click();
  await capture('typography-dark.png');
  await page.locator('#type-size').fill('60');
  assert.equal(await page.locator('#type-size-value').textContent(),'60 px');
  await page.locator('#type-reset').click();
  assert.equal(await page.locator('#type-size-value').textContent(),'46 px');
  await page.reload();
  assert.match(await page.locator('#selections').textContent(),/Palette A \/ Logo L1 \/ Type T1/);
  await page.locator('#clear-selections').click();
  for (const section of ['palettes','logos','typography','references']) {
    await page.setViewportSize({width:390,height:844});
    await page.locator(`[data-section="${section}"]`).click();
    assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth),`Overflow in ${section}`);
    await capture(`${section}-phone.png`);
  }
  await page.setViewportSize({width:1440,height:1100});
  await page.locator('[data-section="palettes"]').click();
  await page.locator('[data-width="375"]').click();
  assert.ok(await page.locator('#app-preview').evaluate(el=>el.scrollWidth<=el.clientWidth),'Phone preview overflow');
  await page.locator('[data-width="full"]').click();
  assert.deepEqual(errors,[]);
  fs.writeFileSync(path.join(__dirname,'VERIFICATION.json'),JSON.stringify({date:'2026-09-30',browser:'Chromium',fonts:fontNames,checks:['4 palettes render','local fonts load','search','reading filter','empty state','sample add dialog','shortlist persistence','logo inversion','typography inversion','type size control','390px responsive sections','375px phone preview','no page errors or failed HTTP assets'],textContrast:contrastResults},null,2)+'\n');
  console.log(JSON.stringify({passed:true,fonts:fontNames.length,palettes:4,textContrast:contrastResults,screenshots:output}));
  await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
