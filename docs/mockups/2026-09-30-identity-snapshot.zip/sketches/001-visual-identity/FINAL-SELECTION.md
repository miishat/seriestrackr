# SeriesTrackr final visual selection

Confirmed by the user on 2026-09-30. Status: design selected; implementation deferred. The user explicitly asked not to implement yet. This decision does not authorize product changes or approve the separate phase 2 discovery workflow.

| Element | Selected direction |
| --- | --- |
| Dark palette | D: Ink & Signal |
| Logo | L2: The next volume, three book spines with the final spine angled |
| Typography | T2: The literary journal, Newsreader + Manrope |

## Palette ingredients

| Role | Value |
| --- | --- |
| Canvas | #171d2b |
| Panel | #212b3d |
| Main text | #eef0e7 |
| Muted text | #b2bdd2 |
| Border | #485773 |
| Primary accent | #b5c4ff |
| Primary button text | #171d2b |
| Soft surface | #343f59 |
| Small secondary highlight | #f5a77e |

The secondary highlight appears on the library eyebrow in the D preview. Keep it restrained when implementing. This selection covers the dark theme; the light theme was not redesigned or selected in this study.

## Type and logo sources

- Headlines and series titles: Newsreader 400.
- Body, controls and metadata: Manrope 400, with 600 for emphasis.
- The selected mark is assets/logos/l2.svg. It uses currentColor and transparent cutouts so it can work on either background.
- Local font files and OFL licenses are in assets/.
- D's palette preview uses fixed Newsreader + DM Sans for fair color comparison. The selected T2 replaces the UI font with Manrope at implementation time. D + L2 + T2 has not yet been assembled into a combined product preview.

## Preserved mockup

index.html retains all four palettes, three marks and four font pairings. screenshots/palette-d.png, screenshots/logos-light.png and screenshots/typography-light.png record the relevant individual studies. FINAL-SELECTION.md and ../MANIFEST.md supersede any old recommendation or browser-local shortlist displayed in the preserved mockup.

## Recommended implementation timing

Keep the production redesign out of a parallel branch while phase 2 is changing the app shell, cards, table and shared stylesheet. Apply the selected identity after the discovery UI is stable, ideally before phase 2's final visual and browser verification. A dedicated follow-up after phase 2 is complete is also safe, with its own visual checks. This is a recommendation only; no scheduling or implementation has been started.
