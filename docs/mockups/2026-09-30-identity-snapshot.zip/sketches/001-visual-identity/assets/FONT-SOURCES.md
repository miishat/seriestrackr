# Local specimen fonts

Latin subsets downloaded from Google Fonts on 2026-09-30. Fonts are used only by this design review artifact. Each family has its OFL license alongside its WOFF2 files.

- Fraunces: https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600&display=swap
  License: https://raw.githubusercontent.com/google/fonts/main/ofl/fraunces/OFL.txt
- DM Sans: https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600&display=swap
  License: https://raw.githubusercontent.com/google/fonts/main/ofl/dmsans/OFL.txt
- Newsreader: https://fonts.googleapis.com/css2?family=Newsreader:wght@400&display=swap
  License: https://raw.githubusercontent.com/google/fonts/main/ofl/newsreader/OFL.txt
- Manrope: https://fonts.googleapis.com/css2?family=Manrope:wght@400;600&display=swap
  License: https://raw.githubusercontent.com/google/fonts/main/ofl/manrope/OFL.txt
- Instrument Serif: https://fonts.googleapis.com/css2?family=Instrument+Serif:wght@400&display=swap
  License: https://raw.githubusercontent.com/google/fonts/main/ofl/instrumentserif/OFL.txt
- Instrument Sans: https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;600&display=swap
  License: https://raw.githubusercontent.com/google/fonts/main/ofl/instrumentsans/OFL.txt
- Syne: https://fonts.googleapis.com/css2?family=Syne:wght@400;600&display=swap
  License: https://raw.githubusercontent.com/google/fonts/main/ofl/syne/OFL.txt
- Work Sans: https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600&display=swap
  License: https://raw.githubusercontent.com/google/fonts/main/ofl/worksans/OFL.txt