---
sketch: 001
name: visual-identity
question: Which colors, mark and typography should express SeriesTrackr?
winner: "D / L2 / T2"
tags: [palette, identity, typography]
---

# Identity workroom

Open index.html directly, or serve the sketch root from the worktree with `python -m http.server 4174 --bind 127.0.0.1 --directory .planning/sketches` and open http://127.0.0.1:4174/001-visual-identity/.

Four dark palettes use an identical bookshelf preview with Newsreader + DM Sans held constant. Three original SVG logo studies are shown in monochrome and at small sizes. Four typography pairings use identical neutral specimens, with a light/dark toggle and headline-size control.

Current app typography, verified in src/styles/app.css: Georgia for h1/h2; system-ui,sans-serif for body and controls at 14px/1.5. The wordmark uses system-ui at 22px bold. No custom webfont is loaded by the app. Windows typically resolves system-ui to Segoe UI.

The workroom includes sample search, reading filter, empty state, add-series dialog, and a local shortlist. Preview records are fictional and isolated from the app's data. Fonts are stored locally in assets, with source and license files. SVG sources are in assets/logos.

Final user selection on 2026-09-30: D (Ink & Signal), L2 (The next volume), T2 (Newsreader + Manrope). Implementation is deferred. Any starting recommendation visible in the frozen mockup is historical; the decision here and in FINAL-SELECTION.md takes precedence. The original HTML and all alternatives remain available for review.

## Verification

Verified with Chromium: all four palettes render with local fonts, search and reading filters work, the empty state and temporary add-series dialog work, shortlist preferences persist across reload, logo and typography backgrounds toggle, and the type-size slider resets. All four sections fit a 390 px viewport; the app preview also fits a 375 px constrained width. No JavaScript errors or failed HTTP assets were observed. The viewport toolbar was moved clear of the shortlist reset control after an interaction check caught an overlap.

The measured body, muted label, accent label and button text pairs exceed 4.5:1 in all four palettes. See VERIFICATION.json for the individual ratios. This is a text contrast check, not a full accessibility audit.

Screenshots are in screenshots/. Product source files are unchanged, so production build and unit tests were not run for this standalone design artifact. Browser checks use the existing checkout's Playwright dependency; no product dependencies were added.
