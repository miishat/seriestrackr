"""Fetch Google Fonts' Latin WOFF2 specimens and their OFL licenses."""
from pathlib import Path
from urllib.request import Request, urlopen
import re

assets = Path(__file__).parent / 'assets'
assets.mkdir(exist_ok=True)
families = [('Fraunces', 'fraunces', '400;500;600'), ('DM Sans', 'dmsans', '400;600'), ('Newsreader', 'newsreader', '400'), ('Manrope', 'manrope', '400;600'), ('Instrument Serif', 'instrumentserif', '400'), ('Instrument Sans', 'instrumentsans', '400;600'), ('Syne', 'syne', '400;600'), ('Work Sans', 'worksans', '400;600')]
headers = {'User-Agent': 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'}

def fetch(url):
    with urlopen(Request(url, headers=headers), timeout=30) as response:
        return response.read()

styles, sources = [], []
for family, folder, weights in families:
    url = f'https://fonts.googleapis.com/css2?family={family.replace(" ", "+")}:wght@{weights}&display=swap'
    css = fetch(url).decode()
    blocks = re.findall(r'/\* latin \*/\s*(@font-face\s*\{[^}]+\})', css)
    if not blocks:
        raise RuntimeError(f'No Latin specimen found for {family}')
    font_urls = {}
    for block in blocks:
        for font_url in re.findall(r'url\((https:[^)]+)\)', block):
            if font_url not in font_urls:
                filename = f'{folder}-{len(font_urls) + 1}.woff2'
                (assets / filename).write_bytes(fetch(font_url))
                font_urls[font_url] = filename
            block = block.replace(font_url, font_urls[font_url])
        styles.append(block)
    license_url = f'https://raw.githubusercontent.com/google/fonts/main/ofl/{folder}/OFL.txt'
    (assets / f'{folder}-OFL.txt').write_bytes(fetch(license_url))
    sources.append(f'- {family}: {url}\n  License: {license_url}')
    print(f'{family}: {len(font_urls)} local font file(s), license saved', flush=True)
(assets / 'fonts.css').write_text('\n\n'.join(styles), encoding='utf-8')
(assets / 'FONT-SOURCES.md').write_text('# Local specimen fonts\n\nLatin subsets downloaded from Google Fonts on 2026-09-30. Fonts are used only by this design review artifact. Each family has its OFL license alongside its WOFF2 files.\n\n' + '\n'.join(sources), encoding='utf-8')
