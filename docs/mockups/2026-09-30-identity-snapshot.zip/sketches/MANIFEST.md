# SeriesTrackr design studies

Requested on 2026-09-30: create an isolated work area and explore dark theme color, a more creative logo, and typography separately before the user chooses.

Design direction: expressive publisher and cultural identity design, with four original dark palettes, three original vector marks, and four independently comparable font pairings. All content is fictional. These are review artifacts; product source has not been changed.

| Study | Design question | Options | Selection |
| --- | --- | --- | --- |
| 001 / palettes | Which dark palette gives the bookshelf character? | A Oxblood & Brass, B Petrol & Apricot, C Aubergine & Acid, D Ink & Signal | D: Ink & Signal |
| 001 / logos | Which symbol expresses reading and continuation? | L1 Returning ribbon, L2 Next volume, L3 Chapter orbit | L2: The next volume |
| 001 / typography | Which font pairing gives the app a distinctive voice? | T1 Fraunces + DM Sans, T2 Newsreader + Manrope, T3 Instrument Serif + Instrument Sans, T4 Syne + Work Sans | T2: Newsreader + Manrope |

Reference points: [Faber & Faber by Pentagram](https://www.pentagram.com/work/faber-faber), [The Public Theater by Pentagram](https://www.pentagram.com/work/the-public-theater), [Fraunces by Undercase Type](https://fraunces.undercase.xyz/), [Instrument Serif](https://github.com/Instrument/instrument-serif).

Final design selection confirmed by the user on 2026-09-30: D, L2, T2. Implementation is deferred at the user's request. The frozen HTML retains all alternatives for future reference. Its browser shortlist is exploratory and does not override this recorded decision.
